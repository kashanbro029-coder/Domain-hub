require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const domains = [
  {id:1,name:"verolux.com",price:75000,featured:true},
  {id:2,name:"pixelnest.pk",price:18000,featured:false},
  {id:3,name:"brandora.com",price:125000,featured:true},
  {id:4,name:"nexivo.net",price:22000,featured:false}
];

app.get("/api/domains",(req,res)=>res.json(domains));
app.post("/api/orders",(req,res)=>{
  const {domainId,customerName,customerEmail}=req.body;
  const d=domains.find(x=>x.id===Number(domainId));
  if(!d)return res.status(404).json({error:"Domain not found"});
  if(!customerName||!customerEmail)return res.status(400).json({error:"Name and email are required"});
  res.json({
    orderId:"ORD-"+crypto.randomBytes(5).toString("hex").toUpperCase(),
    domain:d.name,amount:d.price,paymentProvider:"Easypaisa",
    status:"pending",
    message:"Demo order created. Add official Easypaisa Online Payment API integration and credentials on the server before accepting live payments."
  });
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("DomainHub running"));
